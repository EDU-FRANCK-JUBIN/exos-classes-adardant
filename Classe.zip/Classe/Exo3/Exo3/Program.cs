﻿using System;

namespace Exo3
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
