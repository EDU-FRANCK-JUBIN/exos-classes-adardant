﻿using System;

namespace Exo3
{
    class Article
    {
        private int reference;
        private string designation;
        private double prixHT;
        private static double tauxTVA;

        public int getReference()
        {
            return this.reference;
        }

        public string getDesignation()
        {
            return this.designation;
        }

        public double getPrixHT()
        {
            return this.prixHT;
        }

        public static double getTauxTVA()
        {
            return tauxTVA;
        }

        public Article() {}

        public Article(int a, string b)
        {
            reference = a;
            designation = b;
        }

        public Article(Article a)
        {
            reference = a.reference;
            designation = a.designation;
            prixHT = a.prixHT;

        }

        public Article(int a, string b, double c)
        {
            reference = a;
            designation = b;
            prixHT = c;

        }

        public double CalculerPrixTTC()
        {
            return prixHT*(1+tauxTVA/100);
        }

        public void AfficherArticle()
        {
            Console.Out.WriteLine("Référence : " + reference + " désignation : " + designation + " prix HT : " + prixHT);
        }
    }
}
