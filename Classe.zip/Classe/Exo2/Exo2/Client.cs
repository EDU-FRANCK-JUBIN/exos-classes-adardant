﻿using System;

namespace Exo2
{
    class Client
    {
        private string cin;
        private string nom;
        private string prenom;
        private string tel;

        public string getCin() 
        {
            return this.cin;
        }
        public string getNom()
        {
            return this.nom;
        }
        public string getPrenom()
        {
            return this.prenom;
        }
        public string getTel()
        {
            return this.tel;
        }

        public Client(string cin, string nom, string prenom, string tel)
        {
            this.cin = cin;
            this.nom = nom;
            this.prenom = prenom;
            this.tel = tel;
        }

        public Client(string cin, string nom, string prenom)
        {
            this.cin = cin;
            this.nom = nom;
            this.prenom = prenom;
        }

        public void Afficher()
        {
            Console.Out.WriteLine("cin: " + cin + " nom: " + nom + " prenom: " + prenom);
            if (tel != "")
            {
                Console.Out.WriteLine("Tél : " + tel);
            }
        }
    }
}
