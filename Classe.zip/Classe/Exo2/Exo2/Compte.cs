﻿using System;
namespace Exo2
{
    class Compte
    {
        private int numero;
        private double solde;
        private Client proprietaire;
        private static int nombreDecomptes = 0;

        public Compte(Client proprietaire)
        {
            nombreDecomptes++;
            this.numero = nombreDecomptes;
            this.proprietaire = proprietaire;
        }

        public int getNumero()
        {
            return this.numero;
        }

        public double getSolde()
        {
            return this.solde;
        }

        public Client getProprietaire()
        {
            return this.proprietaire;
        }

        public void Crediter(double somme)
        {
            this.solde += somme;
        }

        public void Crediter(Compte c, double somme)
        {
            if (c.solde >= somme)
            {
                c.solde -= somme;
                this.solde += somme;
            }
            else
                Console.Out.WriteLine("compte insuffisant");
        }

        public void Debiter(double somme)
        {
            if (this.solde >= somme)
            {
                this.solde -= somme;
            }
            else
                Console.Out.WriteLine("compte insuffisant");
        }

        public void Debiter(Compte c, double somme)
        {
            if (this.solde >= somme)
            {
                this.solde -= somme;
                c.solde += somme;
            }
            else
                Console.Out.WriteLine("compte insuffisant");
        }

        public void Afficher()
        {
            Console.Out.WriteLine("Numéro : " + numero + " solde : " + solde + " propriétaire : ");
            proprietaire.Afficher();
        }

        public static void NombreDeComptes()
        {
            Console.Out.WriteLine(nombreDecomptes);
        }

    }
}
