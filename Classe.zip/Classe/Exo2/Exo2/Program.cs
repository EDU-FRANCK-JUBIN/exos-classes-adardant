﻿using System;

namespace Exo2
{
    class Program
    {
        static void Main(string[] args)
        {

            Compte C1 = new Compte(new Client("123", "DARDANT", "Aurel", "1234"));
            C1.Afficher();

            Console.Out.Write("déposer: ");
            double montant = double.Parse(Console.In.ReadLine());
            C1.Crediter(montant);
            C1.Afficher();

            Console.Out.Write("retirer: ");
            double montant2 = double.Parse(Console.In.ReadLine());
            C1.Debiter(montant2);
            C1.Afficher();

            Compte C2 = new Compte(new Client("345", "Fraix", "Hugo", "89076"));
            C2.Afficher();

            Console.Out.Write("déposer sur aurelien a partir d'hugo: ");
            double montant3 = double.Parse(Console.In.ReadLine());
            C2.Crediter(C1, montant3);
            Console.Out.WriteLine("déposer sur hugo a partir d'aurelien");
            double montant4 = double.Parse(Console.In.ReadLine());
            C1.Debiter(C2, montant4);

            C1.Afficher();
            C2.Afficher();

        }
    }
}
