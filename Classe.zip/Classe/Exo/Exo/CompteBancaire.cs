﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo
{
    public class CompteBancaire
    {
        private string titulaire;
        private double solde;
        private string devise;

        public CompteBancaire(string titulaire, double solde, string devise)
        {
            this.titulaire = titulaire;
            this.solde = solde;
            this.devise = devise;
        }

        public string getTitulaire()
        {
            return this.titulaire;
        }

        public double getSolde()
        {
            return this.solde;
        }

        public string getDevise()
        {
            return this.devise;
        }

        public void Crediter(double montant)
        {
            this.solde = this.solde + montant;
        }

        public void Debiter(double montant)
        {
            this.solde = solde - montant;
        }

        public string Decrire()
        {
            return "Le solde du compte de " + this.titulaire + " est de " + this.solde + " " + this.devise;
        }
    }

}
