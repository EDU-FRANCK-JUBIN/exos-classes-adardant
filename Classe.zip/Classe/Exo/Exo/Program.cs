﻿using System;

namespace Exo
{
    class Program
    {
        static void Main(string[] args)
        {
            CompteBancaire compte = new CompteBancaire("TOTO", 5000, "euros");

            Console.WriteLine(compte.Decrire());

            compte.Debiter(500);

            Console.WriteLine(compte.Decrire());

            compte.Crediter(250);

            Console.WriteLine(compte.Decrire());
        }
    }
}
